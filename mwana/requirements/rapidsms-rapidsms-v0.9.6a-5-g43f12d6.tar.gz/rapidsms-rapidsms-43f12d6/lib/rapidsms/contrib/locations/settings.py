#!/usr/bin/env python
# vim: ai ts=4 sts=4 et sw=4

MAP_DEFAULT_LATITUDE  = 40.726111
MAP_DEFAULT_LONGITUDE = -73.981389
