#!/usr/bin/env python
# vim: ai ts=4 sts=4 et sw=4

MESSAGE_TESTER_TIMEOUT  = 5
MESSAGE_TESTER_INTERVAL = 0.2
