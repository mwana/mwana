# -*- coding: utf-8 -*-
"""Needed to make this package a Django app"""
