"Build SMS applications with Python and Django"


__version__ = '0.15.0'
