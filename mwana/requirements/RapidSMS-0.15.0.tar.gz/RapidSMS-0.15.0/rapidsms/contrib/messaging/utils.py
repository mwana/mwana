#!/usr/bin/env python
# vim: ai ts=4 sts=4 et sw=4


def send_message(connection, text):
    raise DeprecationWarning("rapidsms.contrib.messaging.utils is deprecated")
