from rapidsms.backends.kannel.outgoing import KannelBackend

__all__ = ('KannelBackend',)
