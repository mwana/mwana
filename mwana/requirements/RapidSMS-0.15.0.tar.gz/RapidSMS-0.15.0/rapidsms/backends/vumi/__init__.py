from rapidsms.backends.vumi.outgoing import VumiBackend

__all__ = ('VumiBackend',)
