from rapidsms.router.blocking.router import BlockingRouter

__all__ = ('BlockingRouter',)
