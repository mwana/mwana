from rapidsms.router.celery.router import CeleryRouter

__all__ = ('CeleryRouter',)
