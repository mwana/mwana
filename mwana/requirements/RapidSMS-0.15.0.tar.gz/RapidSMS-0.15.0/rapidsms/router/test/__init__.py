from rapidsms.router.test.router import TestRouter

__all__ = ('TestRouter',)
