from default import *

NOSE_ARGS = [
    '--with-coverage',
    '--cover-package=rapidsms',
]
