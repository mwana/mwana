from settings import *

INSTALLED_APPS = ('south',) + INSTALLED_APPS
