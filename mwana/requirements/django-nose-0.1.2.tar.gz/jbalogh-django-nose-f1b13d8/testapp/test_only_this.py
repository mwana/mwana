"""
Django's test runner won't find this, but nose will.
"""


def test_multiplication():
    assert 2 * 2 == 4
