#!/usr/bin/env python
# vim: et ts=4 sw=4

from .settings import DjAppSettings
settings = DjAppSettings()
