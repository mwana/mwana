"Auto-complete selection widgets using Django and jQuery UI."


__version__ = '0.7.0'