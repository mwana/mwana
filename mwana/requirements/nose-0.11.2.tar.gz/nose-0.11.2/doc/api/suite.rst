.. automodule :: nose.suite
   :members: