# vim: ai ts=4 sts=4 et sw=4


import logging
import rapidsms
from mwana.apps.labresults.messages import *

logger = logging.getLogger(__name__)


class App(rapidsms.apps.base.AppBase):

    def start(self):
        """Configure your app in the start phase."""
#        self.schedule_notification_task()
        pass

    def handle(self, message):
        pass

    def default(self, message):
        pass

    