# vim: ai ts=4 sts=4 et sw=4
import re
from rapidsms.contrib.handlers.handlers.keyword import KeywordHandler
from mwana.apps.labtests.models import Result

UNGREGISTERED = "Sorry, you must be registered with Results160 to receive DBS \
results. If you think this message is a mistake, respond with keyword 'HELP'"

SORRY         = "Sorry, we didn't understand that message."

class ViralLoadHandler(KeywordHandler):
    """
    clinic_worker >> RESULT <sampleid>
    clinic_worker << <sampleid>: <result>

    Unknown Sample
    clinic_worker << Sorry, I don't know about a sample with id %(requisition_id)s.
    Please check your DBS records and try again.

    No results yet*
    clinic_worker << The results for sample %(requisition_id)s are not yet ready. You will be notified when they are.
    * this may not be possible, depending on the data we are able to collect
    """

    keyword = "vl|blood|viral load|viralLoad"
    PATTERN = re.compile(r'(\S+)')

    def help(self):
        self.handle("")

  
    def _not_unique(self, result, results):
        return results.filter(requisition_id=result.requisition_id).count() > 1

    def handle(self, text):
        text = text.strip()
        if not self.msg.contact:
            self.respond(UNGREGISTERED)
            return
        if self.is_sentence(text):
            self.respond("%s Send the keyword HELP if you need to be helped." % (SORRY))
            return

        location = self.msg.contact.location
        results = Result.objects.filter(clinic=location, notification_status__in=['new', 'notified'])[:9]

        if results:
            msg_text = 'Here are your results: '
            # @type res Result
            msg_text += '**** '.join("%s;%s %s" % (res.requisition_id, res.result, res.result_unit) for res in results)
            self.respond(msg_text)
            for res in results:
                res.notification_status = 'sent'
            return True

        else:
            self.respond("Sorry, %s. There are no new results available for %s. You will be notified when new results are ready" % (self.msg.contact.name, location.name))
            return True